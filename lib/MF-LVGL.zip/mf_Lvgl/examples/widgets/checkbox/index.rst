
Simple Checkboxes
"""""""""""""""""

.. lv_example:: widgets/checkbox/lv_example_checkbox_1
  :language: c

Checkboxes as radio buttons
"""""""""""""""""""""""""""
.. lv_example:: widgets/checkbox/lv_example_checkbox_2
  :language: c

