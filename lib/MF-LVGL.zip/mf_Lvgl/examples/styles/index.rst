
Size styles
"""""""""""""""""""

.. lv_example:: styles/lv_example_style_1
  :language: c

Background styles
"""""""""""""""""""

.. lv_example:: styles/lv_example_style_2
  :language: c

Border styles
""""""""""""""""

.. lv_example:: styles/lv_example_style_3
  :language: c

Outline styles
""""""""""""""""

.. lv_example:: styles/lv_example_style_4
  :language: c

Shadow styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_5
  :language: c

Image styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_6
  :language: c

Arc styles
""""""""""""""""""""""""

.. lv_example:: style/lv_example_style_7
  :language: c

Text styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_8
  :language: c

Line styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_9
  :language: c


Transition
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_10
  :language: c


Using multiple styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_11
  :language: c


Local styles
""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_12
  :language: c


Add styles to parts and states
"""""""""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_13
  :language: c


Extending the current theme
""""""""""""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_14
  :language: c


Opacity and Transformations
""""""""""""""""""""""""""""""""""

.. lv_example:: styles/lv_example_style_15
  :language: c


